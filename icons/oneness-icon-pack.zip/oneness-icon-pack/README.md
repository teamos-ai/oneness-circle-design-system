# Iconography — the standard pack

> Chapter XII of **The Oneness Circle — Design System**
> Volume I · Edition II · MMXXVI

This folder is the whole icon layer of the system: one library, one weight, one
addressing scheme, and a manifest that lets a coding agent resolve a *meaning*
into a glyph without guessing at names.

**Download the pack:** [`oneness-icon-pack.zip`](oneness-icon-pack.zip) · 4.1 MB ·
1,512 glyphs × 6 weights (9,072 SVG files) + both sprites + the manifest + the licence.

---

## Two layers, one vocabulary

| Layer | Count | ID scheme | Lives in | Purpose |
|---|---|---|---|---|
| **House glyphs** | 39 | `#icon-{name}` | inline sprite in `index.html` | The bespoke marks that carry brand meaning. |
| **Standard pack** | 1,512 | `#i-{name}` | `oneness-icons.svg` | Utility, navigation, wayfinding — the long tail. |

Where a house glyph exists, it **outranks** the pack. Where it does not, the pack
answers — and no new icon gets drawn. Per the client brief, only **four custom
icons** are sanctioned for core pages beyond the existing house set.

---

## Files

| File | What it is |
|---|---|
| `oneness-icons.json` | **The token manifest.** Start here if you are an agent. Contract, semantic tokens, and all 1,512 glyphs with categories + tags for search. |
| `oneness-icons.svg` | Full sprite — all 1,512 glyphs, `regular` weight, as `<symbol id="i-{name}">`. |
| `oneness-core.svg` | Brand-core sprite — the 53 glyphs behind the semantic tokens. Prefer this for site builds; it is 29 KB against 734 KB. |
| `oneness-icon-pack.zip` | The complete pack, all six weights, for download. |
| `LICENSE-phosphor.txt` | MIT licence for the underlying pack. |

---

## The contract

```html
<svg class="ico ico-md"><use href="/icons/oneness-icons.svg#i-leaf"/></svg>
```

That is the only shape a pack glyph takes. Five rules govern it:

1. **Resolve meaning first.** Look up `semantic["pillar.vitality"]` before you go
   looking for an icon called `leaf`. Sixty brand meanings are mapped; they encode
   decisions the naming does not.
2. **One weight — `regular`.** Sitewide, without exception. The other five weights
   ship in the archive for completeness. Mixing them dissolves the vocabulary.
3. **Size through a token.** `--toc-icon-xs` … `--toc-icon-2xl`
   (14 · 16 · **20 default** · 24 · 32 · 48px), wearable as `.ico-xs` … `.ico-2xl`.
   A raw pixel size on a glyph is a defect.
4. **Never set a fill.** Every symbol carries `fill="currentColor"` and takes the ink
   of whatever it sits in. To override, set the *element's* colour with an ink token —
   `--toc-icon-ink-quiet`, `--toc-icon-ink-thread`, `--toc-icon-ink-onDark`.
5. **Gold ink needs the safe gold.** Sacred Gold `#B8965A` measures 2.6:1 on ivory and
   fails WCAG AA. For a gold glyph on a light ground use `--toc-icon-ink-thread`
   (gold-700 `#7B6435`, 5.36:1).

### Ink tokens

| Token | Resolves to | Use on |
|---|---|---|
| `--toc-icon-ink` | `currentColor` | the default — inherit the surface |
| `--toc-icon-ink-quiet` | `--toc-ink-500` | meta and secondary glyphs |
| `--toc-icon-ink-thread` | `--toc-gold-700` | gold glyphs on a light ground |
| `--toc-icon-ink-onDark` | `--toc-ivory` | violet · sage · blue grounds |

---

## For coding agents

Read [`oneness-icons.json`](oneness-icons.json). It is the single source of truth and
needs no other context.

```js
const m = await fetch('/icons/oneness-icons.json').then(r => r.json());

// 1 — meaning → glyph (preferred)
m.semantic['action.virtual-tea'].token        // "i-tea-bag"
m.semantic['pillar.gene-keys'].token          // "i-dna"

// 2 — search by tag or category, when no semantic token fits
m.icons.filter(i => i.tags.includes('meditation'))
m.icons.filter(i => i.categories.includes('nature'))

// 3 — the rules, in machine form
m.contract.rules
```

Semantic groups: `pillar` · `offering` · `action` · `botanical` · `science` ·
`practice` · `sound` · `editorial` · `social` · `status`.

The `offering` group encodes the colour-by-offer mapping from the client brief —
Young Living → green, ARCEA → blue, core brand → gold + violet — so an agent picking
an icon for a page also picks up which colourway that page belongs to.

---

## Attribution

The standard pack is [**Phosphor Icons**](https://phosphoricons.com) v2.1.1, MIT
licensed. Glyphs are redistributed unmodified on their native 256-unit grid; the
Oneness Circle layer adds the sprite, the token scheme, and the semantic map.
